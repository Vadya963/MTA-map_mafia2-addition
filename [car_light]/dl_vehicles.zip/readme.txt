Resource: dl_vehicles v0.0.1
Author: Ren712
Contact: knoblauch700@o2.pl

Description:
This resource lets You create per pixel lights for vehicles. It uses custom functions
introduced in dl_lightmanager and dl_core resources. It works for most of the vehicles, 
including trains. You can easily change light properties using variables in c_vehicleLight.lua
