--
-- c_exports.lua
--

----------------------------------------------------------------------------------------------------
-- exports
----------------------------------------------------------------------------------------------------
function getRenderTargets()
	if targetTable.RTColor and targetTable.RTNormal then
		return targetTable.RTColor, targetTable.RTNormal
	else
		return false, false
	end
end

function passGTASAObjectNormals(isPassNormals)
	if shaderTable.SHWorld and shaderTable.SHWorldNoZWrite then
		return functionTable.disableNormals(not isPassNormals)
	else
		return false
	end
end