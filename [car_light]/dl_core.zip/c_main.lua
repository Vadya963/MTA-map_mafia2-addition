
local scx, scy = guiGetScreenSize()
local enablePedVS = true
isFXSupported = (tonumber(dxGetStatus().VideoCardNumRenderTargets) > 1 and tonumber(dxGetStatus().VideoCardPSVersion) > 2 
	and tostring(dxGetStatus().DepthBufferFormat) ~= "unknown")
	
---------------------------------------------------------------------------------------------------
-- shader lists
---------------------------------------------------------------------------------------------------
if enablePedVS then pedShader = "fx/RTinput_ped.fx" else pedShader = "fx/RTinput_ped_noVS.fx" end
shaderParams = { 
	SHWorld = {"fx/RTinput_world.fx", 0, 0, false, "world,object"}, -- world
	SHWorldRefAnim = {"fx/RTinput_world_refAnim.fx", 1, 0, false, "world,object"}, -- world
	SHGrass = {"fx/RTinput_grass.fx", 0, 0, false, "world"}, -- world (grass)
	SHWorldNoZWrite = {"fx/RTinput_world_noZWrite.fx", 2, 0, false, "world,object,vehicle"}, -- world
	SHWaterWake = {"fx/RTinput_water_detail.fx", 3, 0, false, "world,object"}, -- world (waterwake)
	SHWaterDetail = {"fx/RTinput_water_detail.fx", 3, 0, false, "world,object"}, -- world (waterwake)
	SHWater = {"fx/RTinput_water.fx", 0, 0, false, "world,object"}, -- world (water)
	SHVehPaint = {"fx/RTinput_car_paint.fx", 0, 0, false, "vehicle"}, -- vehicle paint
	SHPed = {pedShader, 0, 0, false, "ped"}
				}

isDRShValid = false
isDRRtValid = false
isDREnabled = false
		
----------------------------------------------------------------------------------------------------------------------------
-- onClientResourceStart/Stop
----------------------------------------------------------------------------------------------------------------------------
function switchDLOn()
	functionTable.enableCore()
	CPrmFixZ.create()
	setElementData(localPlayer, "dl_core.on", true, false )
end


function switchDLOff()
	functionTable.disableCore()
	CPrmFixZ.destroy()
	setElementData(localPlayer, "dl_core.on", false, false )
end

addEventHandler( "onClientPreRender", root,
    function()
		if not isDREnabled then return end
		CPrmFixZ.draw()
		dxSetRenderTarget( targetTable.RTColor, true )
		dxSetRenderTarget(targetTable.RTNormal, true )
		dxSetRenderTarget()
    end
, true, "high+20" )

---------------------------------------------------------------------------------------------------
-- manage render targets
---------------------------------------------------------------------------------------------------
functionTable = {}

function functionTable.enableCore()
	if isDREnabled then return end
	if functionTable.createWorldShaders() and functionTable.createRenderTargets() then
		for i, thisPart in pairs(shaderTable) do
			functionTable.applyRTToTextureShader(thisPart)
		end
		engineApplyShaderToWorldTexture(shaderTable.SHWorld, "*")
		functionTable.removeShaderFromList(shaderTable.SHWorld, textureListTable.RemoveList)
		functionTable.removeShaderFromList(shaderTable.SHWorld, textureListTable.ZDisable)
		functionTable.applyShaderToList(shaderTable.SHWorld, textureListTable.ApplyList)
		engineRemoveShaderFromWorldTexture(shaderTable.SHWorld, "unnamed")
		
		functionTable.applyShaderToList(shaderTable.SHWorldRefAnim, textureListTable.ApplySpecial)
	
		functionTable.applyShaderToList(shaderTable.SHWorldNoZWrite, textureListTable.ZDisableApply)
		dxSetShaderValue(shaderTable.SHWorldNoZWrite, "sWorldZBias", 0.005 )		

		functionTable.applyShaderToList(shaderTable.SHVehPaint, textureListTable.TextureGrun)		
		engineApplyShaderToWorldTexture(shaderTable.SHVehPaint, "vehiclegeneric256")
		engineApplyShaderToWorldTexture(shaderTable.SHVehPaint, "*")
		engineRemoveShaderFromWorldTexture(shaderTable.SHVehPaint, "unnamed")

		engineApplyShaderToWorldTexture(shaderTable.SHPed, "*")	
		engineApplyShaderToWorldTexture(shaderTable.SHGrass, "tx*")
		engineApplyShaderToWorldTexture(shaderTable.SHWater, "water*")
		engineRemoveShaderFromWorldTexture(shaderTable.SHWater, "waterwake")
		
		engineApplyShaderToWorldTexture(shaderTable.SHWaterWake, "waterwake")
		dxSetShaderValue(shaderTable.SHWaterWake, "sWorldZBias", 0.45 )
		
		functionTable.applyShaderToList(shaderTable.SHWaterDetail, textureListTable.Detail)
		dxSetShaderValue(shaderTable.SHWaterDetail, "sWorldZBias", 0.01 )
		
		isDREnabled = true
	end
end

function functionTable.disableCore()
	if isDREnabled then
		local isDisabled = not functionTable.destroyWorldShaders()
		isDisabled = isDisabled and not functionTable.destroyRenderTargets()
		isDREnabled = not isDisabled
	end
end

shaderTable = {}
function functionTable.createWorldShaders()
	if not isDRShValid then
		shaderTable = {}
		shaderTable.SHWorld = dxCreateShader(unpack(shaderParams.SHWorld))
		shaderTable.SHWorldRefAnim = dxCreateShader(unpack(shaderParams.SHWorldRefAnim))
		shaderTable.SHGrass = dxCreateShader(unpack(shaderParams.SHGrass))
		shaderTable.SHWorldNoZWrite = dxCreateShader(unpack(shaderParams.SHWorldNoZWrite))
		shaderTable.SHWaterWake = dxCreateShader(unpack(shaderParams.SHWaterWake))
		shaderTable.SHWaterDetail = dxCreateShader(unpack(shaderParams.SHWaterDetail))
		shaderTable.SHWater = dxCreateShader(unpack(shaderParams.SHWater))
		shaderTable.SHPed = dxCreateShader(unpack(shaderParams.SHPed))
		shaderTable.SHVehPaint = dxCreateShader(unpack(shaderParams.SHVehPaint))

		isDRShValid = true
			
			for i,thisPart in pairs(shaderTable) do
				isDRShValid = thisPart and isDRShValid
			end
	end
	return isDRShValid
end

function functionTable.destroyWorldShaders()
	if isDRShValid then
		for _,thisPart in pairs(shaderTable) do
			engineRemoveShaderFromWorldTexture(thisPart, "*")
			destroyElement(thisPart)
			thisPart = nil
		end
	isDRShValid = false 
	end
	return isDRShValid
end

targetTable = {}
function functionTable.createRenderTargets()
	if not isDRRtValid then
		targetTable.RTColor = dxCreateRenderTarget( scx , scy, false )
		targetTable.RTNormal = dxCreateRenderTarget( scx , scy, false )
		isDRRtValid = true
		for _,thisPart in pairs(targetTable) do
			isDRRtValid = thisPart and isDRRtValid
		end
	end
	return isDRRtValid
end

function functionTable.disableNormals(isDisableNormals)
	if shaderTable.SHWorld and shaderTable.SHWorldNoZWrite and shaderTable.SHWorldRefAnim then
		dxSetShaderValue( shaderTable.SHWorld, "sDisableNormals", isDisableNormals )
		dxSetShaderValue( shaderTable.SHWorldRefAnim, "sDisableNormals", isDisableNormals )
		dxSetShaderValue( shaderTable.SHWorldNoZWrite, "sDisableNormals", isDisableNormals )
		return true
	end
	return false
end

function functionTable.destroyRenderTargets()
	if isDRRtValid then
		for _,thisPart in pairs(targetTable) do
			destroyElement(thisPart)
			thisPart = nil
		end
	isDRRtValid = false 
	end
	return isDRRtValid
end

function functionTable.applyRTToTextureShader(myShader)
	if myShader then
		dxSetShaderValue( myShader, "ColorRT", targetTable.RTColor )
		dxSetShaderValue( myShader, "NormalRT", targetTable.RTNormal )
	end
end

function functionTable.applyShaderToList(myShader, myList)
	for _,applyMatch in ipairs(myList) do
		engineApplyShaderToWorldTexture(myShader, applyMatch)	
	end
end

function functionTable.removeShaderFromList(myShader, myList)
	for _,removeMatch in ipairs(myList) do
		engineRemoveShaderFromWorldTexture(myShader, removeMatch)	
	end
end